

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`student_manager` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `student_manager`;

/*Table structure for table `goout` */

DROP TABLE IF EXISTS `goout`;

CREATE TABLE `goout` (
  `sid` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `snum` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ssex` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sage` int DEFAULT NULL,
  `cid` varchar(20) DEFAULT NULL,
  `sremark` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `entime` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=COMPACT;

/*Data for the table `goout` */

insert  into `goout`(`sid`,`sname`,`snum`,`ssex`,`sage`,`cid`,`sremark`,`address`,`entime`) values (1,'刘一','13596873216','男',20,'陕西西安','打工','湖北省十堰市丹江口市武当山','2023-03-25'),(2,'刘二','13596873217','女',17,'陕西西安','打工','四川省乐山市峨眉山市峨眉山','2023-03-25'),(3,'刘三','13596873218','女',16,'陕西西安','打工','北京市东城区汝阳王府','2023-03-25'),(4,'刘四','13596873219','男',18,'陕西西安','打工','浙江省杭州市牛家村','2023-03-25'),(5,'刘五','13596873220','女',16,'陕西西安','打工','浙江省舟山市桃花岛','2023-03-25'),(6,'马一','13596873221','男',17,'陕西西安','打工','陕西省西安市终南山','2023-03-25'),(7,'马二','13596873222','女',16,'陕西西安','打工','陕西省西安市终南山','2023-03-25'),(8,'马三','13596873223','男',20,'陕西西安','打工','云南省大理市大理皇宫','2023-03-25');

/*Table structure for table `local` */

DROP TABLE IF EXISTS `local`;

CREATE TABLE `local` (
  `sid` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `snum` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ssex` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sage` int DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=COMPACT;

/*Data for the table `local` */

insert  into `local`(`sid`,`sname`,`snum`,`ssex`,`sage`,`address`) values (1,'张一','13596873216','男',20,'陕西西安'),(2,'张二','13596873217','女',17,'陕西西安'),(3,'张三','13596873218','女',16,'陕西西安'),(4,'张四','13596873219','男',18,'陕西西安'),(5,'张五','13596873220','女',16,'陕西西安'),(6,'李一','13596873221','男',17,'陕西西安'),(7,'李二','13596873222','女',16,'陕西西安'),(8,'李三','13596873223','男',20,'陕西西安'),(9,'李四','13596873224','男',23,'陕西西安'),(10,'李五','13596873225','男',21,'陕西西安'),(11,'王一','13596873226','女',17,'陕西西安'),(12,'王二','13596873227','男',18,'陕西西安');

/*Table structure for table `manager` */

DROP TABLE IF EXISTS `manager`;

CREATE TABLE `manager` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `password` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `remark` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=COMPACT;

/*Data for the table `manager` */

insert  into `manager`(`id`,`username`,`password`,`name`,`remark`) values (1,'admin','admin','root','管理员');

/*Table structure for table `outside` */

DROP TABLE IF EXISTS `outside`;

CREATE TABLE `outside` (
  `sid` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `snum` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ssex` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sage` int DEFAULT NULL,
  `cid` varchar(20) DEFAULT NULL,
  `sstatus` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sremark` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `entime` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=COMPACT;

/*Data for the table `outside` */

insert  into `outside`(`sid`,`sname`,`snum`,`ssex`,`sage`,`cid`,`sstatus`,`sremark`,`address`,`entime`) values (1,'张无忌','13596873216','男',20,'陕西西安','有','走亲访友','湖北省十堰市丹江口市武当山','2023-03-25'),(2,'周芷若','13596873217','女',17,'陕西西安','有','走亲访友','四川省乐山市峨眉山市峨眉山','2023-03-25'),(3,'赵敏','13596873218','女',16,'陕西西安','有','走亲访友','北京市东城区汝阳王府','2023-03-25'),(4,'郭靖','13596873219','男',18,'陕西西安','有','走亲访友','浙江省杭州市牛家村','2023-03-25'),(5,'黄蓉','13596873220','女',16,'陕西西安','有','走亲访友','浙江省舟山市桃花岛','2023-03-25'),(6,'杨过','13596873221','男',17,'陕西西安','有','走亲访友','陕西省西安市终南山','2023-03-25'),(7,'小龙女','13596873222','女',16,'陕西西安','有','走亲访友','陕西省西安市终南山','2023-03-25'),(8,'段誉','13596873223','男',20,'陕西西安','有','走亲访友','云南省大理市大理皇宫','2023-03-25'),(9,'乔峰','13596873224','男',23,'陕西西安','有','走亲访友','内蒙古赤峰市南院大王府','2023-03-25'),(10,'虚竹','13596873225','男',21,'陕西西安','有','走亲访友','河南省郑州市登封市少林寺','2023-03-25'),(11,'王语嫣','13596873226','女',17,'陕西西安','有','走亲访友','江苏省苏州市吴中区金庭镇曼陀山庄','2023-03-25'),(12,'陆冠英','13596873227','男',18,'陕西西安','有','走亲访友','江苏省无锡市宜兴市周铁镇归云庄','2023-03-25'),(13,'贾宝玉','13596873228','男',15,'陕西西安','有','走亲访友','江苏省南京市秦淮区荣国公府','2023-03-25'),(14,'林黛玉','13596873229','女',13,'陕西西安','有','走亲访友','江苏省苏州市姑苏区林府','2023-03-25'),(15,'薛宝钗','13596873230','女',16,'陕西西安','有','走亲访友','江苏省南京市秦淮区薛府','2023-03-25'),(16,'贾探春','13596873231','女',14,'陕西西安','有','走亲访友','江苏省南京市秦淮区荣国公府','2023-03-25'),(17,'王熙凤','13596873232','女',23,'陕西西安','有','走亲访友','江苏省南京市秦淮区王府','2023-03-25'),(18,'蔡徐坤','13596873239','男',25,'陕西西安','有','走亲访友','北京市海淀区知春路','2023-03-25');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
