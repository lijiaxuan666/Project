package com.wangpeng.dao;

//不要删
public interface RoomDao {

}
